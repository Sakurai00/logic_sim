#pragma once

#include <stdbool.h>
#include <stdio.h>

#include "main.h"

extern void sim(void);
