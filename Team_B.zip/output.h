#pragma once

#define OUTPUT_FILENAME "output.txt"

#include <stdio.h>

#include "main.h"

extern void output(void);
