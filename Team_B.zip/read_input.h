#pragma once

#define INPUT_FILENAME "input.txt"

#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "read_logic.h"

extern void read_input();

extern void test_read_input();
